public class UsoClaseGenerica3{
public static void main(String[] args){

	ClaseGenerica3 <Integer,Double> i=new ClaseGenerica3<Integer,Double>(12,2.3);
	
	System.out.println(i.getA());
	System.out.println(i.getB());

	
	
	

}
}